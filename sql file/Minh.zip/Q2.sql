SELECT author
FROM course_table, learningmaterial
WHERE learningmaterial.courseid = course_table.cid 
        and course_table.lecturer != learningmaterial.author;