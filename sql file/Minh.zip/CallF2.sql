declare ret varchar(15);
BEGIN
    ret := Best_Teachers();
    dbms_output.put_line(ret);
END;
/