CREATE OR REPLACE FUNCTION Best_Teachers
    /*Chon ra nhung giang vien co dong gop cho bai giang cua giang vien khac*/
RETURN varchar
AS T varchar(15);
BEGIN
    SELECT fname||' '||lname
    INTO T
    FROM USER_TABLE
    WHERE username IN 
    (SELECT author
     FROM COURSE_TABLE, LEARNINGMATERIAL
     WHERE course_table.CID = learningmaterial.courseid and course_table.lecturer != learningmaterial.author);
    return T;
END;
/