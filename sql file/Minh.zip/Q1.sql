SELECT fname||' '||lname as Full_Name,
        email,
        country,
        dob,
        addresu
FROM USER_TABLE, STUDENT_TABLE
WHERE user_table.username = student_table.username;