ALTER SESSION SET NLS_DATE_FORMAT = 'MM-DD-YYYY';
    /*Them nguoi hoc moi va thong tin cua ho*/
CREATE OR REPLACE PROCEDURE Insert_Student
(
    Nusername    in user_table.username%TYPE,
    Npass        in user_table.pass%TYPE,
    Nfname       in user_table.fname%TYPE,
    Nlname       in user_table.lname%TYPE,
    Nemail       in user_table.email%TYPE,
    Ncountry     in user_table.country%TYPE,
    Ndob         in user_table.dob%TYPE,
    Naddresu     in user_table.addresu%TYPE,
    Noccupation  in student_table.occupation%TYPE
)
AS 
BEGIN
    INSERT INTO user_table VALUES (Nusername, Npass, Nfname, Nlname, Nemail, Ncountry, Ndob, Naddresu);
    
    INSERT INTO student_table VALUES (Nusername, Noccupation);
    
    Commit;
END;